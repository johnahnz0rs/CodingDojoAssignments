To-Do:


new_user.html
    [ ] create template
    [ ] style template
    [ ] write the logic
    