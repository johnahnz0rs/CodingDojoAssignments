Hi.

You may notice that there is no css in this assignment. I did that on purpose because:

As I was finishing an assignment yesterday, I noticed that I spent, in this order, about 30 minutes on the html, then another 60 min on just the css alone, and finally 10 minutes to wrap up the back-end logic.

I was astounded! I LOVE the back-end, and css is my least favorite language; but the time I spent on each section reflected the exact opposite of my preferences/enjoyment.

So I made a conscious decision to experiment with another approach:
first, set up the server and write the html;
then, completely ignore the css until the very end, if at all;
then, write all the routes and back-end logic;
and finally, if i feel like it, if i feel the assignment REQUIRES styling my view(s), to do it at the very end of the assignment.

As you can see, I thought this assignment did not require styling -- instead, I think the point of this assignment was to practice CRUD. So that's what I focused on.

Thanks, boo.

Love,
johnahnz0rs is l33t