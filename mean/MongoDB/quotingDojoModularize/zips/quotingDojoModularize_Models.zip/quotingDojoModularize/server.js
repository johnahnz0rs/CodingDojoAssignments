// server setup
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');


app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');



mongoose.connect('mongodb://localhost/quoting_dojo');
mongoose.Promise = global.Promise;


// schema
require('./server/models/quote.js');



// routes
require('./server/config/routes.js')(app);


// start server
app.listen(1337, function() {
	console.log('johnahnz0rs is listening on port 1337')
});