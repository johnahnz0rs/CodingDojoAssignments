const mongoose = require('mongoose');
const Schema = mongoose;


const QuoteSchema = new mongoose.Schema({
    name: {type: String},
    quote: {type: String}
}, {timestamps: true});

// model
mongoose.model('Quote', QuoteSchema);
const Quote = mongoose.model('Quote');


module.exports = Quote;