var mathlib = require('./mathlib')();



console.log('***** johnahnz0rs is l33t *****');

console.log(mathlib.add(2,4));
console.log(mathlib.multiply(3,4));
console.log(mathlib.square(4));
console.log(mathlib.random(3,12));


console.log('***** johnahnz0rs is l33t ******');